import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-log-in',
  templateUrl: './log-in.component.html',
  styleUrls: ['./log-in.component.css']
})
export class LogInComponent implements OnInit {
   myReactiveForm!: FormGroup;
  // studentservice: any;
  // studentInfo: any;

  constructor() { }

  ngOnInit(): void {
    this.myReactiveForm = new FormGroup({
      'user': new FormControl(null, [Validators.required,Validators.email]),
      'password': new FormControl(null,[Validators.required,Validators.minLength(8)])
    }); 
   }
   
   loginUser(){
     console.log(this.myReactiveForm.value);
   }
   
   get user(){
     return this.myReactiveForm.get('user')
   }

   get password(){
     return this.myReactiveForm.get('password')
   }
}
