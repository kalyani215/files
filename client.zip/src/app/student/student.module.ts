export class Tutorial {
  name?:string;
  password?:string;
  
}
