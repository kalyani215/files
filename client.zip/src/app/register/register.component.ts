import { variable } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  myReactiveForm!: FormGroup;
  constructor() { }

  ngOnInit(): void {
    this.myReactiveForm = new FormGroup({
      'name': new FormControl(null, [Validators.required,Validators.pattern('[a-zA-z]+$')]),
      'email_id': new FormControl(null,[Validators.required,Validators.email]),
      'password': new FormControl(null, [Validators.required,Validators.minLength(8),Validators.pattern('/^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[a-zA-Z]).{8,}$/')]),
      'Re_enter_password': new FormControl(null, [Validators.required]),
      'mobile_no': new FormControl(null, [Validators.required]),
      'birthdate': new FormControl(null, [Validators.required]),
      'age': new FormControl(null, [Validators.required]),
    }); 
  }

  RegisterUser(){
    console.log(this.myReactiveForm.value);
  }

  

  get name(){
    return this.myReactiveForm.get('name');
  }

  get email_id(){
    return this.myReactiveForm.get('email_id');
  }

  get password(){
    return this.myReactiveForm.get('password');
  }

  get Re_enter_password(){
    return this.myReactiveForm.get('Re_enter_password');
  }

  get mobile_no(){
    return this.myReactiveForm.get('mobile_no');
  }

  get birthdate(){
    return this.myReactiveForm.get('birthdate');
  }

  get age(){
    return this.myReactiveForm.get('age');
  }

}
